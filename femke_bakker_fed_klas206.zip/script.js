// function voor als je op de button drukt naar boven te gaan //

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}